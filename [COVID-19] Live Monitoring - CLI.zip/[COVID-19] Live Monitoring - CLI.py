import time

notif = "=" * 22 + "-[Notifikasi]-" + "=" * 22

print("=" * 58)
print("=" * 20 + "-[LiveMonitoring]-" + "=" * 20)
print("=" * 58)
print(''' ██████╗ ██████╗ ██╗   ██╗██╗██████╗        ██╗ █████╗
██╔════╝██╔═══██╗██║   ██║██║██╔══██╗      ███║██╔══██╗
██║     ██║   ██║██║   ██║██║██║  ██║█████╗╚██║╚██████║
██║     ██║   ██║╚██╗ ██╔╝██║██║  ██║╚════╝ ██║ ╚═══██║
╚██████╗╚██████╔╝ ╚████╔╝ ██║██████╔╝       ██║ █████╔╝
 ╚═════╝ ╚═════╝   ╚═══╝  ╚═╝╚═════╝        ╚═╝ ╚════╝''')
print("=" * 58)
print("=" * 15 + f"-[{time.asctime( time.localtime(time.time()))}]-" + "=" * 15)

jam = time.localtime().tm_hour
if jam >= 0 and jam <= 10:
    print("=" * 21 + "-[Selamat Pagi]-" + "=" * 21)

elif jam > 10 and jam <= 14:
    print("=" * 21 + "-[Selamat Siang]-" + "=" * 20)

elif jam > 14 and jam <= 18:
    print("=" * 21 + "-[Selamat Sore]-" + "=" * 21)

elif jam > 18 and jam <= 24:
    print("=" * 21 + "-[Selamat Malam]-" + "=" * 20)

total = 0
enter = 0

while True:
    try:
        import requests
        print("=====-[Menu]-" + "=" * 45)
        print("[1]> Monitoring Global\n[2]> Monitoring Positif\n[3]> Monitoring Sembuh\n[4]> Monitoring Meninggal\n[5]> Monitoring Indonesia\n[6]> Pilih Negara\n[7]> Keluar\n")
        pilih = int(input("[+]> Masukkan Pilihan: "))
        print()

        if pilih == 1:
            print("=====-[Hasil Monitoring Global]-" + "=" * 26)
            for i in requests.get("https://api.kawalcorona.com").json():
                print("[1]> Negara              :", i["attributes"]["Country_Region"])
                print("[2]> Update Terakhir     :", i["attributes"]["Last_Update"])
                print("[3]> Positif             :", i["attributes"]["Confirmed"])
                print("[4]> Sembuh              :", i["attributes"]["Recovered"])
                print("[5]> Meninggal           :", i["attributes"]["Deaths"] , "\n")
                total += 1

            print("[+]> Total Negara        :", total, "\n")
            total = total - total

        elif pilih == 2:
            print("=====-[Hasil Monitoring Positif]-" + "=" * 25)
            print("[+]> Total Pasien Positif        :", requests.get("https://api.kawalcorona.com/positif").json()["value"], "\n")

        elif pilih == 3:
            print("=====-[Hasil Monitoring Sembuh]-" + "=" * 26)
            print("[+]> Total Pasien Sembuh         :", requests.get("https://api.kawalcorona.com/sembuh").json()["value"], "\n")

        elif pilih == 4:
            print("=====-[Hasil Monitoring Meninggal]-" + "=" * 23)
            print("[+]> Total Pasien Meninggal      :", requests.get("https://api.kawalcorona.com/meninggal").json()["value"], "\n")

        elif pilih == 5:
            print("=====-[Hasil Monitoring Indonesia]-" + "=" * 23)
            for i in requests.get("https://api.kawalcorona.com").json():
                if i["attributes"]["Country_Region"] == "Indonesia":
                    print("[1]> Negara              :", i["attributes"]["Country_Region"])
                    print("[2]> Update Terakhir     :", i["attributes"]["Last_Update"])
                    print("[3]> Positif             :", i["attributes"]["Confirmed"])
                    print("[4]> Sembuh              :", i["attributes"]["Recovered"])
                    print("[5]> Meninggal           :", i["attributes"]["Deaths"], "\n")

        elif pilih == 6:
            print("=====-[Daftar Negara]-" + "=" * 36)
            for i in requests.get("https://api.kawalcorona.com").json():
                print(i["attributes"]["Country_Region"], end='\t\t')
                enter += 1
                if enter == 5:
                    print("\n")
                    enter = enter - enter

            negara = str(input("\n\n[+]> Silahkan Pilih Negara: "))
            print("\n=====-[Hasil Monitoring Negara]-" + "=" * 26)
            for i in requests.get("https://api.kawalcorona.com").json():
                if i["attributes"]["Country_Region"] == negara:
                    print("[1]> Negara              :", i["attributes"]["Country_Region"])
                    print("[2]> Update Terakhir     :", i["attributes"]["Last_Update"])
                    print("[3]> Positif             :", i["attributes"]["Confirmed"])
                    print("[4]> Sembuh              :", i["attributes"]["Recovered"])
                    print("[5]> Meninggal           :", i["attributes"]["Deaths"], "\n")

            enter = enter - enter

        elif pilih == 7:
            print(notif)
            print("\t   [$]> Created By. UyizDofukizi <[$]\n")
            break

        else:
            print(notif)
            print("\t  [!!]> Pilihan Tidak Tersedia <[!!]\n")

    except ValueError:
        print(notif)
        print("\t [!!]> Inputan Anda Tidak Sesuai <[!!]\n")

    except ModuleNotFoundError:
        print(notif)
        print("       [!!]> Silahkan Install Module requests <[!!]")
        print(">>> pip install requests")
        break

    except requests.exceptions.ConnectionError:
        print(notif)
        print("[!!]> Silahkan Sambungkan Perangkat Anda Ke Internet <[!!]\n")
